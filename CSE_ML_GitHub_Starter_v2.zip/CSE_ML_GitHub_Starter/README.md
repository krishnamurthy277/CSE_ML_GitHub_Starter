# CSE Department ML Project: Student Placement Prediction (Starter)

A small, reproducible scikit-learn classification project intended as a template for CSE student teams. The included CSV is **illustrative demo data only**; it is not suitable for real placement decisions or research claims.

## What it does
- Trains a Logistic Regression model to predict the demo `placed` label from CGPA, aptitude score, and internship experience.
- Reports accuracy and a classification report.
- Saves a trained model locally to `models/placement_model.joblib`.
- Offers a command-line prediction example.
- Includes a unit test and GitHub Actions workflow for automatic checks.

## Requirements
- Python 3.10 or 3.11 recommended
- Git

## Run locally on Windows PowerShell
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m src.train
python -m src.predict --cgpa 8.1 --aptitude 78 --internship 1
python -m pytest -q
```

If `py -3.11` is unavailable, install Python 3.11 from https://www.python.org/downloads/ and enable **Add python.exe to PATH**, or use an installed Python version by replacing `py -3.11` with `python`.

## Project structure
```text
CSE_ML_GitHub_Starter/
├── .github/workflows/python-tests.yml
├── data/placement_demo.csv
├── src/__init__.py
├── src/train.py
├── src/predict.py
├── tests/test_model.py
├── requirements.txt
├── .gitignore
└── README.md
```

## Push to your department repository
Create an empty repository in the department GitHub organization, then run these commands from this folder:
```powershell
git init
git add .
git commit -m "Add placement prediction ML starter"
git branch -M main
git remote add origin https://github.com/YOUR-ORG/YOUR-REPO.git
git push -u origin main
```
Replace `YOUR-ORG/YOUR-REPO` with the real repository path. Do not commit passwords, API keys, private student information, or large datasets.

## Faculty review process
1. Faculty opens the department repository on GitHub.
2. Review `README.md`, source code, dataset description, test results, and report.
3. Students submit changes using a pull request.
4. GitHub Actions runs tests on pushes and pull requests. Faculty can inspect the **Actions** tab for results.
5. Faculty leaves feedback on the pull request and approves/requests changes.

## Run in the browser
If enabled for the organization/account, GitHub Codespaces can provide a browser-based VS Code terminal. Open the repository, choose **Code → Codespaces → Create codespace**, then run the commands above. Availability and included usage depend on the GitHub plan/organization settings.

## Academic submission checklist
- [ ] Problem statement and objectives
- [ ] Dataset source, license, columns, and limitations
- [ ] Data cleaning and preprocessing explanation
- [ ] Baseline and chosen model justification
- [ ] Train/test split and evaluation metrics
- [ ] Results, confusion matrix, limitations, and future work
- [ ] Reproducible setup instructions
- [ ] Team members and faculty guide listed in repository description/README
- [ ] No secrets or sensitive personal data committed

## Important limitation
This is a teaching starter, not a production placement screening system. Do not use its predictions to make real admissions, hiring, or placement decisions.
