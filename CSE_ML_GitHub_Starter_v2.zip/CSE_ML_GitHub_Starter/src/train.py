from pathlib import Path
import joblib
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "placement_demo.csv"
MODEL_DIR = ROOT / "models"
MODEL_PATH = MODEL_DIR / "placement_model.joblib"
FEATURES = ["cgpa", "aptitude", "internship"]


def train_model():
    data = pd.read_csv(DATA_PATH)
    X = data[FEATURES]
    y = data["placed"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    model = make_pipeline(StandardScaler(), LogisticRegression(random_state=42))
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    print(f"Demo test accuracy: {accuracy_score(y_test, predictions):.3f}")
    print(classification_report(y_test, predictions, zero_division=0))
    MODEL_DIR.mkdir(exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    print(f"Saved model to: {MODEL_PATH}")
    return model


if __name__ == "__main__":
    train_model()
