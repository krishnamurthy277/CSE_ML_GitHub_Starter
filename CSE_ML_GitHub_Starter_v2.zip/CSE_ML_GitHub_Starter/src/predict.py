import argparse
from pathlib import Path
import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "models" / "placement_model.joblib"


def main():
    parser = argparse.ArgumentParser(description="Predict a demo placement label")
    parser.add_argument("--cgpa", type=float, required=True, help="CGPA, e.g. 8.1")
    parser.add_argument("--aptitude", type=float, required=True, help="Aptitude score, e.g. 78")
    parser.add_argument("--internship", type=int, choices=[0, 1], required=True, help="0=no, 1=yes")
    args = parser.parse_args()
    if not MODEL_PATH.exists():
        raise SystemExit("Model not found. Run: python -m src.train")
    model = joblib.load(MODEL_PATH)
    sample = pd.DataFrame([{
        "cgpa": args.cgpa,
        "aptitude": args.aptitude,
        "internship": args.internship,
    }])
    prediction = int(model.predict(sample)[0])
    label = "Placed (demo prediction)" if prediction == 1 else "Not placed (demo prediction)"
    print(label)
    if hasattr(model, "predict_proba"):
        print(f"Model score for placed class: {model.predict_proba(sample)[0][1]:.3f}")
    print("Reminder: illustrative model only; do not use for real placement decisions.")


if __name__ == "__main__":
    main()
