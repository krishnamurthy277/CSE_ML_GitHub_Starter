"""CSE Department ML project starter package."""
