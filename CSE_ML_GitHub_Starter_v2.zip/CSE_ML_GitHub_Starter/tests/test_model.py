from pathlib import Path
import pandas as pd
from src.train import DATA_PATH, FEATURES, train_model


def test_demo_dataset_and_model():
    data = pd.read_csv(DATA_PATH)
    assert set(FEATURES + ["placed"]).issubset(data.columns)
    assert data["placed"].isin([0, 1]).all()
    model = train_model()
    sample = pd.DataFrame([{"cgpa": 8.1, "aptitude": 78, "internship": 1}])
    prediction = model.predict(sample)
    assert len(prediction) == 1
    assert int(prediction[0]) in (0, 1)
